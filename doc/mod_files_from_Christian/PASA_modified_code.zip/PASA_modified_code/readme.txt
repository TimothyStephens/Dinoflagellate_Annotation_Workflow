# to make PASA support non-canonical splice site.

# modified file:
PASA/PerlLib/CDNA/CDNA_alignment.pm
# modified block:
line 334 - 360
